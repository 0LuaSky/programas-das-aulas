/*Criar uma matriz de ordem 5 e imprima: toda a matriz e depois os números que se encontram em posições cuja a linha mais a coluna formam um número ímpar. */

#include <iostream>
using namespace std;

int main(){
	int i, o, x, y, mat[5][5];
	
	for(i=0; i<5; i++){
		for(o=0; o<5; o++){
			cout << "Preencha a matriz de ordem 5\n";
			for(y=0; y<i; y++){
				for(x=0; x<5; x++){
					cout << mat[y][x] << "\t";
				}
				cout << "\n";
			}
			cout << endl;
			for(x=0; x<o; x++){
				cout << mat[i][x] << "\t";
			}
			cin >> mat[i][o];
			system("clear||cls");
		}
	}
	
	cout << "matriz normal:\n";
	for(i=0; i<5; i++){
		for(o=0; o<5; o++){
			cout << mat[i][o] << "\t";
		}
		cout << "\n";
	}
	
	cout << "matriz prima:\n";
	for(i=0; i<5; i++){
		for(o=0; o<5; o++){
			if((i+o)%2 == 1){
				cout << mat[i][o] << "\t";
			}else{
				cout << "--\t";
			}
		}
		cout << "\n";
	}
	
	cout << endl << endl;
	system("pause");
}
