/*Ler valores inteiros para a matriz A[3][5]. Gerar e imprimir o vetor Soma_Linha, onde cada elemento é a soma dos elementos de uma linha da matriz A.
Faça o trecho que gera a matriz separadamente da entrada e saída. */

#include <iostream>
using namespace std;

int main(){
	int i, o, x, y, mat[3][5], vet[3]={0,0,0};
	
	for(i=0; i<3; i++){
		for(o=0; o<5; o++){
			cout << "Preencha a matriz de 3 X 5\n";
			for(y=0; y<i; y++){
				for(x=0; x<5; x++){
					cout << mat[y][x] << "\t";
				}
				cout << "\n";
			}
			cout << endl;
			for(x=0; x<o; x++){
				cout << mat[i][x] << "\t";
			}
			cin >> mat[i][o];
			system("clear||cls");
		}
	}
	for(i=0; i<3; i++){
		for(o=0; o<5; o++){
			cout << mat[i][o] << "\t";
		}
		cout << "\n";
	}
	cout << endl;
	cout << "A soma ddas linhas e:\n";
	cout << endl;
	for(i=0; i<3; i++){
		for(o=0; o<5; o++){
			vet[i] += mat[i][o];
			cout << mat[i][o];
			if(o==4){
				cout << " = \t";
			}else{
				cout << " + \t";
			}
		}
		cout << vet[i];
		cout << "\n";
		
		
	}
	cout << endl << endl;
	system("pause");
}