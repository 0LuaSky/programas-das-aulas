/*Criar uma matriz 2x3. Gerar e imprimir a transposta dessa matriz. A matriz transposta é gerada trocando linha por coluna.*/

#include <iostream>
using namespace std;

int main(){
	int i, o, x, y, mat[2][3], mot[3][2];
	
	for(i=0; i<2; i++){
		for(o=0; o<3; o++){
			cout << "Preencha a matriz de 2 X 3\n";
			for(y=0; y<i; y++){
				for(x=0; x<3; x++){
					cout << mat[y][x] << "\t";
				}
				cout << "\n";
			}
			cout << endl;
			for(x=0; x<o; x++){
				cout << mat[i][x] << "\t";
			}
			cin >> mat[i][o];
			system("clear||cls");
		}
	}
	
	cout << "matrix a: \n";
	for(i=0; i<2; i++){
		for(o=0; o<3; o++){
			cout << mat[i][o] << "\t";
		}
		cout << "\n";
	}
	
	for(i=0; i<2; i++){
		for(o=0; o<3; o++){
			mot[o][i] = mat[i][o];
		}		
	}
	
	cout << "\nmatriz a':\n";
	for(i=0; i<3; i++){
		for(o=0; o<2; o++){
			cout << mot[i][o] << "\t";
		}
		cout << "\n";
	}
		
	cout << endl << endl;
	system("pause");
}