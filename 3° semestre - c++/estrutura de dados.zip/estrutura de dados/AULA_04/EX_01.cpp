/*Criar uma matriz de ordem 4 e exibir a soma da diagonal principal.*/

#include <iostream>
using namespace std;

int main(){
	int i, o, x, y, mat[4][4], math=0;
	
	for(i=0; i<4; i++){
		for(o=0; o<4; o++){
			cout << "Preencha a matriz de ordem 4\n";
			for(y=0; y<i; y++){
				for(x=0; x<4; x++){
					cout << mat[y][x] << "\t";
				}
				cout << "\n";
			}
			cout << endl;
			for(x=0; x<o; x++){
				cout << mat[i][x] << "\t";
			}
			cin >> mat[i][o];
			system("clear||cls");
		}
	}
	for(i=0; i<4; i++){
		for(o=0; o<4; o++){
			cout << mat[i][o] << "\t";
		}
		cout << "\n";
	}
	cout << endl;
	cout << "A soma diagonal principal e:\n";
	cout << endl;
	for(i=0; i<4; i++){
		cout << mat[i][i];
		if(i==3){
			cout << " =";
		}else{
			cout << " + ";
		}
		math += mat[i][i];
	}
	cout << endl << math;
	cout << endl << endl;
	system("pause");
}