/*Ler os elementos de uma matriz de ordem 6 e imprima o produto dos elementos que estão abaixo da diagonal principal.*/

#include <iostream>
using namespace std;

int main(){
	int i, o, x, y, mat[6][6], math[5];
	
	for(i=0; i<6; i++){
		for(o=0; o<6; o++){
			cout << "Preencha a matriz de ordem 6\n";
			for(y=0; y<i; y++){
				for(x=0; x<6; x++){
					cout << mat[y][x] << "\t";
				}
				cout << "\n";
			}
			cout << endl;
			for(x=0; x<o; x++){
				cout << mat[i][x] << "\t";
			}
			cin >> mat[i][o];
			system("clear||cls");
		}
	}
	
	cout << "matriz:\n";
	for(i=0; i<6; i++){
		for(o=0; o<6; o++){
			cout << mat[i][o] << "\t";
		}
		cout << "\n";
	}

	cout << "\nProduto dos elementos abaixo da diagonal:\n";
	for(o=5; o>0; o--){	
		for(i=0; i<o; i++){
			cout << mat[(i+1)+(5-o)][i] << " ";
			
			if(i==0){
				math[4-o]  = mat[(i+1)+(5-o)][i];
			}else{
				math[4-o] *= mat[(i+1)+(5-o)][i];
			}
			
			if(i==o-1){
				cout << "= ";
			}else{
				cout << "x ";
			}
		}
		cout << math[4-o] << endl;
	}

	cout << endl << endl;
	system("pause");
}