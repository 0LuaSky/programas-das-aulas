#include <iostream>

using namespace std;

class triangulo{
	public:
	int a,b,c;
	
	void entrada(){
		cout << "Entre com dois valores: ";
		cin >> a;
		system("clear||cls");
		cout << "Entre com dois valores: " << a << " ";
		cin >> b;
		system("clear||cls");
		cout << "Entre com dois valores: " << a << " " << b << " ";
		cin >> c;
	}
	
	int verifica(int a, int b, int c){
		if(a < b+c && b < a+c && c < a+b){
			return 1;
		}
			return 0;
		}
	
	void tipo(){
		if(verifica(a,b,c) == 1){
			if (a == b && b == c) {
	   			cout << "Triangulo equilatero." << endl;
			}
			else if(a == b || b == c){
			    cout << "Triangulo isosceles." << endl;
			}
			else{
			    cout << "Triangulo escaleno." << endl;
			}
		}else{
			cout << "Nao e um triangulo.";
		}
	}
};

int main(){
	triangulo obj;
	obj.entrada();
	obj.tipo();
	
	cout << "\n\n";
	system("pause");
}