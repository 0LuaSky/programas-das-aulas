#include <iostream>

using namespace std;

class matematica{
	public:
	float a,b;
	
	void entrada(){
		cout << "Entre com dois valores: ";
		cin >> a;
		system("clear||cls");
		cout << "Entre com dois valores: " << a << " ";
		cin >> b;	
	}
	
	int sum(int a, int b){
		return a+b;
	}
	
	int sub(int a, int b){
		return a-b;
	}
	
	int mul(int a, int b){
		return a*b;
	}
	
	int div(int a, int b){
		if (b != 0){
			return a/b;
		}
		cout << "Erro";
		return 0;
	}
	
};

int main(){
	matematica obj;
	obj.entrada();
	int op;
	cout << "qual operacao deseja fazer?\n1 = soma\n2 = subtracao\n3 = multiplicacao\n4 = divisao\n";
	cin >> op;
	cout << "\n";
	switch (op){
		case 1: cout << obj.sum(obj.a, obj.b); break;
		case 2: cout << obj.sub(obj.a, obj.b); break;
		case 3: cout << obj.mul(obj.a, obj.b); break;
		case 4: cout << obj.div(obj.a, obj.b); break;
		
		default: cout << "Erro"; break;
	}
	cout << "\n\n";
	system("pause");
}