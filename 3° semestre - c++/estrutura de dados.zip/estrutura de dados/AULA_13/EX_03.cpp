#include <iostream>

using namespace std;

class estacionamento{
	public:
	int dia, horaEntrada, horaSaida;
	
	void entrada(){
		cout << "Entre com a data:  ";
		cin >> dia;
		system("clear||cls");
		cout << "Entre com a data:  " << dia << "\nEntre com a hora da entrada: ";
		cin >> horaEntrada;
		system("clear||cls");
		cout << "Entre com a data:  " << dia << "\nEntre com a hora da entrada: " << horaEntrada << "\nEntre com a hora da saida: ";
		cin >> horaSaida;
	}
	
	void calculo(){
		if(horaEntrada<horaSaida){
			cout << "\nvoce deve pagar RS" << (horaSaida-horaEntrada) * 5 << ":00.";
		}
		else{
			cout << "\nErro.";
		}
	}
};

int main(){
	estacionamento obj;
	obj.entrada();
	obj.calculo();
	cout << "\n\n";
	system("pause");
}