#include <iostream>

using namespace std;

class teste{
	public:
	int x,y;
	
	void entrada(){
		cout << "Entre com dois valores: ";
		cin >> x;
		system("clear||cls");
		cout << "Entre com dois valores: " << x << " ";
		cin >> y;
	}
	
};

int main(){
	teste obj;
	obj.entrada();
	cout << "\n\n";
	system("pause");
}