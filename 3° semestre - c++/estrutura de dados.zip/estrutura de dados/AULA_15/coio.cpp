#include <iostream>
using namespace std;
 
class calendario{
    public:
    int dia, mes, ano;
    calendario(int x, int y, int z){
        ano = x;
        mes = y;
        dia = z;
    }
 
bool anoBissexto (){
    if(((ano % 4 == 0) && (ano % 100 != 0)) || (ano % 400 == 0))
        return true;
    else
        return false;
}
 
int diaSemana(int dia, int mes, int ano){
    int f = ano + dia + 3 * (mes - 1) - 1;
    if (mes < 3) ano--;
    else f -= int(0.4 * mes + 2.3);
    f += int (ano / 4) - int ((ano / 100 + 1) * 0.75);
    f %= 7;
    return f+1;
}
 
void imprimiCalend(){
    cout <<"\n\nDOM\tSEG\tTER\tQUA\tQUI\tSEX\tSAB\n\n";
    short TamanhoDoMes[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
 
    if (anoBissexto() == true)
        TamanhoDoMes[1] = 29;
    for(int j = 1; j < diaSemana(1, mes, ano); j++) cout <<'\t';
 
    for(int dia = 1; dia <= TamanhoDoMes[mes - 1]; dia++){
        if(dia < 10) cout << '0' <<dia <<'\t';
        else cout << dia <<'\t';
 
        if(diaSemana(dia, mes, ano) == 7) cout <<'\n';
 
    }
 
    
}
};
 
 
int main() {
    int a = 2023, m = 1, d = 1;
    calendario Obj(a, m, d);

	for(m;m<12;m++){
		Obj.imprimiCalend();	
	}
 
    return 0;
}