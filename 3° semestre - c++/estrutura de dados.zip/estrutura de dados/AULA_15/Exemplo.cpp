#include <iostream>
using namespace std;

int main(){
	int a,b,soma, *pont1, *pont2;
	cout <<"digite os valores\n";
	cin >> a >> b;
	pont1 = &a;
	pont2 = &b;
	
	cout << &a << endl;
	cout << &b << endl;
	cout << pont1 << endl;
	cout << pont2 << endl;
	
	soma=a+b;
	*pont1 = soma;
	cout << "valor da variave A " << a << endl;
	
	cout << "\n\n";
	system("pause");
}