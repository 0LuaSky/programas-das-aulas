/*Desenvolver um programa onde você entre via teclado com dois valores e após a digitação o usuário escolha um seletor de opção (menu) com as seguintes opções:
- Multiplicação;
- Adição;
- Divisão;
- Subtração;
- Fim do processo;
Obs. Criar um método para cada opção e dentro do case chamar as funções respectivamente.*/

#include <iostream>
using namespace std;

float multiplicacao (float a, float b){
	float multiplicacao = a*b;
	return multiplicacao;
}

float soma (float a, float b){
	float soma = a+b;
	return soma;
}

float Divisao (float a, float b){
	float Divisao = a/b;
	return Divisao;
}

float Subtracao (float a, float b){
	float Subtracao = a-b;
	return Subtracao;
}

int main(){
	float num1, num2;
	int op;

	cout << "Entre com 2 numeros:\n";
	cin >> num1;
	system("clear||cls");
	cout << "Entre com 2 numeros:\n" << num1 << "	";
	cin >> num2;
	cout << "selecione uma das opcoes a seguir:\n[1] - Multiplicacao.\n[2] - Adicao\n[3] - Divisao\n[4] - Subtracao\n[5] - cancelar\n\n";
	cin >> op;
	system("clear||cls");
	cout << "Entre com 2 numeros:\n" << num1 << "	" << num2 << "\nselecione uma das opcoes a seguir:\n[1] - Multiplicacao.\n[2] - Adicao\n[3] - Divisao\n[4] - Subtracao\n[5] - cancelar\n\n";
		
	switch (op){
		default:cout << "Erro, opcao invalida."; break;
		case 1: cout << "[1] multiplicacao: " << num1 << " * " << num2 << " = " << multiplicacao(num1, num2); break;
		case 2: cout << "[2] Adicao: " << num1 << " + " << num2 << " = " << soma(num1, num2); break;
		case 3: cout << "[3] Divisao: " << num1 << " / " << num2 << " = " << Divisao(num1, num2); break;
		case 4: cout << "[4] Subtracao: " << num1 << " - " << num2 << " = " << Subtracao(num1, num2); break;
		case 5: cout << "[5] cancelar: operacao cancelada"; break;
	}
	cout << endl << endl;
	system("pause");
	return 0;
}