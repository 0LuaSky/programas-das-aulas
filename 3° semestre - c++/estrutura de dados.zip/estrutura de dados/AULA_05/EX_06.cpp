/*Gere um método que trabalhe com fatorial, lembrando o fatorial é ele vezes a quantidade dele mesmo. Ex. fat 5 = 5*4*3*2*1.*/

#include <iostream>
using namespace std;

	int fator(int a){
		int fator = a;
		for (int i=a-1; i>0; i--){
			fator *= i;
		}
		return fator;
	}

int main(){
	int num;
	cout << "Entre com um valor:  ";
	cin >> num;
	cout << "O fator do numero e: " << fator(num);
	cout << endl << endl;
	system("pause");
	return 0;
}