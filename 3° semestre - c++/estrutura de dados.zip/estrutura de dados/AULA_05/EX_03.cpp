/*Um número primo é qualquer inteiro divisível por si próprio e por 1. Escreva um método que receba um inteiro positivo e, se este número for primo retorne 1, caso contrário retorne 0.*/

#include <iostream>
using namespace std;

int primo (int a){
	int call = 0;
	for (int i=1; i<a; i++){
		if (a%i == 0){
			call ++;
		}
	}
	return call;
}

int main(){
	int num;
	cout << "entre com um numero: ";
	cin >> num;
	if (primo(num) <= 1){
		cout << "O numero e primo.";
	}else{
		cout << "O numero nao e primo.";		
	}
	cout << endl << endl;
	system("pause");
	return 0;
}