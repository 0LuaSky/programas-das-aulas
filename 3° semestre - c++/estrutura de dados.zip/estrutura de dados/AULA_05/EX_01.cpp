/*Desenvolva um programa que tenha dois métodos fahrenheit e celsius, onde você entra com um valor em fahrenheit e transforma em celsius e vice e versa.
Fórmula Celsius: (fahrenheit – 32) * 5/9;
Fahrenheit = (Celsius * 9/5) + 32;*/

#include <iostream>
using namespace std;

float fahrenheit(float a){
	float fah = (a - 32) * 5 / 9;
	return fah;
}

float celsius(float a){
	float fah = (a * 9/5) + 32 ;
	return fah;
}

int main(){
	float cel, fah;
	cout << "Entre com a temperatura em fahrenheit:  ";
	cin >> fah;
	cout << "Entre com a temperatura em Celsius:     ";
	cin >> cel;
	cout << "\nconvertendo " << fah << "f para Celsius: " << fahrenheit(fah);
	cout << "\nconvertendo " << cel << "c para fahrenheit: " << celsius(cel);
	cout << endl << endl;
	system("pause");
	return 0;
}

