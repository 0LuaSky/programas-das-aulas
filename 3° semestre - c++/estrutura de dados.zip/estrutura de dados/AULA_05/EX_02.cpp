/*Calcule a soma dos quadrados de dois números fornecidos pelo usuário. Trabalhe com chamada de métodos usadas como argumento de outros métodos.
Dica: você vai criar 3 métodos onde duas delas estarão dentro de uma.*/

#include <iostream>
using namespace std;

float quad1 (float a){
	float quad = a*a;
	return quad;
}

float quad2 (float a){
	float quad = a*a;
	return quad;
}

float soma (float a, float b){
	float sum = quad1(a) + quad2(b);
	return sum;
}

int main(){
	float num1, num2;
	cout << "entre com 2 numeros:\n";
	cin >> num1 >> num2;
	cout << "A soma de seus quadrados:\n" << quad1(num1) << " + " << quad2(num2) << " = " << soma(num1,num2);
	cout << endl << endl;
	system("pause");
	return 0;
}