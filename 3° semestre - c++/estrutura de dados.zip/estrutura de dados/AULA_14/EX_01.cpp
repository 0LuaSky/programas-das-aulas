#include <iostream>
using namespace std;

class conta{
	public:
		int numero; double saldo; double limite; string nome;
	
	Conta (int a, double b,double c, string d){
		this->numero=a;
		this->saldo=b;
		this->limite=c;
		this->nome=d;
	}
};




int main(){
	conta obj ;
	int a;
	double b, c;
	string d;
	
	cout << "Entre com o numero da conta, o saldo, o limite de transferencia e o nome do dono da conta:\n";
	cin >> a>>b>>c>>d;
	
	obj.Conta(a,b,c,d);
	
	reset:
	system("clear||cls");
	cout << "Saldo da conta: " << obj.saldo << "____________________________" <<endl;
	
	
	cout << 
	
	cout << "\n\n";
	system("pause");
}