#include <iostream>
#include <math.h>

using namespace std;

int main(){
	float a,b,c;
	cout << "entre com o angulo A: ";
	cin >> a;
	cout << "entre com o angulo B: ";
	cin >> b;
	cout << "entre com o angulo C: ";
	cin >> c;
	if (a == b && a == c && b == c){
		cout << "o trianglu e equilatero ";
	}else if (a == b || a == c || b == c){
		cout << "o triangulo e isosceles ";
	}else{
		cout << "o triangulo e escaleno  ";
	}
	cout << "\n";
	system("pause");
}