#include <iostream>
#include <math.h>

using namespace std;

int main(){
	int a;
	cout << "entre com o numero: ";
	cin >> a;
	if(a % 2 == 0){
		cout << "o numero e par";
	}else{
		cout << "o numero nao e par";
	}
	cout << "\n";
	system("pause");
}