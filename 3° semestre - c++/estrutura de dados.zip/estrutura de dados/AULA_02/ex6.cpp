#include <iostream>
#include <math.h>

using namespace std;

int main(){
	int a;
	cout << "entre com a idade: ";
	cin >> a;
	if(a >= 0 && a <12){
		cout << "crianca";
	}else if (a <18){
		cout << "adolecente";
	}else if (a <50){
		cout << "adulto(a)";
	}else{
		cout << "idoso(a)";
	}
	cout << "\n";
	system("pause");
}