#include <iostream>

using namespace std;

int main(){
	float a,b,c;
	cout << "entre com o lado A: ";
	cin >> a;
	cout << "entre com o lado B: ";
	cin >> b;
	c = (a*b)/ 2;
	cout << "a area do triangulo e: " << c;
	cout << "\n";
	system("pause");
}