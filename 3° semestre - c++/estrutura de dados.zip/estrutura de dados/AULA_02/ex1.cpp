#include <iostream>
#include <math.h>

using namespace std;

int main(){
	float a,b,c,x1,x2;
	cout << "entre com A: ";
	cin >> a;
	cout << "entre com B: ";
	cin >> b;
	cout << "entre com C: ";
	cin >> c;
	x1 = (-b + sqrt((b*b) - (4*a*c)))/(2*a);
	x2 = (-b - sqrt((b*b) - (4*a*c)) ) /2*a;
	cout << "X1: " << x1 << "\nX2: " << x2 << "\n";
	system("pause");
}