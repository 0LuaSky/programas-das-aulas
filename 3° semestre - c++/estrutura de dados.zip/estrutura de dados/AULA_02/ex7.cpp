#include <iostream>
#include <math.h>

using namespace std;

int main(){
	int a;
	cout << "entre com A: ";
	cin >> a;
	if((a %4 == 0 && a% 100 != 0) || a % 400 == 0){
		cout << "o ano e bissexto";
	}else{
		cout << "o ano nao e bissexto";
	}
	cout << "\n";
	system("pause");
}