#include <iostream>
#include <math.h>

using namespace std;

int main(){
	float a,b,c,d, media, maior, menor;
	cout << "entre com A: ";
	cin >> a;
		maior = a;
		menor = a;
	cout << "entre com B: ";
	cin >> b;
		if (b > maior){
			maior = b;
		}
		if (b > menor){
			menor = b;
		}
	cout << "entre com C: ";
	cin >> c;
		if (c > maior){
			maior = c;
		}
		if (c > menor){
			menor = c;
		}
	cout << "entre com d: ";
	cin >> d;
		if (d > maior){
			maior = d;
		}
		if (d > menor){
			menor = d;
		}
	media = (a+b+c+d)/4;	
	cout << "\nMaior valor: " << maior << "\nMenor valor: " << menor << "\nMedia: " << media;
	cout << "\n";
	system("pause");
}