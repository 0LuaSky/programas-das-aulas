#include <iostream>
#include <math.h>

using namespace std;

int main(){
	float a,b,c,d;
	cout << "entre com a base A: ";
	cin >> a;
	cout << "entre com a base B: ";
	cin >> b;
	cout << "entre com a altura: ";
	cin >> c;
	d = ((a+b)*c);
	cout << "a area do trapezio e: " << d;
	cout << "\n";
	system("pause");
}