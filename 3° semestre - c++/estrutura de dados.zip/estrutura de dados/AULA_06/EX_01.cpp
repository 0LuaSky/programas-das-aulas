//Faça agora um método de Fibonacci usando a recursividade;​

#include <iostream>
using namespace std;

int Fibonacci(int n, int x, int y){
	if (n>0){
		int z = x;
		x = x + y;
		y = z;
		return Fibonacci(n-1,x,y);
	}
	return x;
}

int main(){
	int n;
	restart:
	cout << "entre com o indice da seguencia: ";
	cin >> n;
	cout << Fibonacci(n-1,1,0);	
	cout << "\nDeseja recomecar (0/1): ";
	cin >> n;
	if(n == 1){
		system("clear||cls");
		goto restart;
	}else{
		cout << "fim do programa.";
		cout << endl << endl;
	}
	system("pause");
	return 0;
}   
