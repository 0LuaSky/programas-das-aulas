#include <iostream>
using namespace std;

int main(){
	int i;
	float notas[5] = {4.5,7.9,5.9,3.5,4.8};
	cout << "exibindo valores:\n\n";
	for(i = 0;i<=4;i++){
		cout << notas[i] << endl;
	}
	cout << endl << endl;
	system("pause");
}