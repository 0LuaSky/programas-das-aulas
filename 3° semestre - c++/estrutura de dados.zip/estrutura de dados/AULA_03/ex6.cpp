/*Criar um vetor com a 8 elementos e ordená-los.*/

#include <iostream>
using namespace std;

int main(){
/*	int i, o, z;
	float x[8], y[8];
	cout << "Entre com os 8 valores do vetor\n";
	for (i=0; i<8; i++){
		cin >> x[i];		
	}
	
	for (i=7; i>=0; i--){
		y[i] = x[i];
		for(o=7; o>=0; o--){
			if(y[i]<x[o]){
				y[i] = x[o];
				z = o;	
			}
		}
		x[z] = 0; 
	}
	
	cout << endl;
	
	for(i=0; i<8; i++){
		cout << y[i] << endl;
	}*/
	
	int i, y, x, val[8], va[8];
	cout << "entre com os 8 valores do vetor:\n";
	for (i=0; i<8; i++){
		cin >> val[i];		
	}
	for (i=7; i>=0; i--){
		va[i] = val[i];
		for (y=0; y<8; y++){
			if (val[y] >= va[i]){
				va[i] = val[y];
				x = y;
			}
		}
		val[x] =0;
	}
	
	cout << endl;
	
	for(i=0; i<8; i++){
		cout << va[i] << endl;
	}
	system("pause");
}