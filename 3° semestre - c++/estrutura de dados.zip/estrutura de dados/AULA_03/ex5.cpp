/*Criar um programa que leia dados de um vetor de 12 elementos inteiros. Imprima o maior e menor sem ordenar, o percentual de números pares e a média dos elementos do vetor.*/

#include <iostream>
using namespace std;

int main(){
	int val[12], i, maior, menor;
	float percent, media;
	
	cout << "entre com 12 valores:\n";
	for (i=0; i<12; i++){
		cin >> val[i];
		if (i == 0){
			maior = i;
			menor = i;
			media = val[i];	
			if(val[i]%2 == 0){
				percent = 1;
			}
		}else{			
			if(val[i] > maior){
				maior = i;	
			}
			if(val[i] < menor){
				menor = i;
			}
			media = media + val[i];
			if(val[i]%2 == 0){
				percent++;
			}
		}
	}
	system("clear||cls");
	media = media/12;
	percent = (percent*100)/12;
	
	cout << "O maior valor: " << val[maior] << endl;
	cout << "O menor valor: " << val[menor] << endl;
	cout << "A media:       " << media << endl;
	cout << "A porcentagem de numeros par:  " << endl << percent << "%\n\n";
	system("pause");
}