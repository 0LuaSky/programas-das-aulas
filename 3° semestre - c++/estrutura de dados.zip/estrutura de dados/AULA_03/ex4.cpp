/*Ler um vetor V de 10 elementos e obter um vetor W cujos componentes são os fatoriais dos respectivos componentes de V.*/

#include <iostream>
using namespace std;

int main(){
	int i,o;
	double val[10], va[10];
	
	for(i=0; i<10; i++){
		system("clear||cls");
		cout << "entre com o " << i+1 << " valor:\n";
		cin >> val[i];
	}
	
	for(i=0; i<10; i++){
		va[i] = val[i];
		for(o = val[i]-1; o>0; o--){
			va[i] = va[i] * o;
		}
	}
	
	system("clear||cls");
	
	for(i=0; i<10; i++){
		cout << "vetor " << i << ":  " << val[i] << "  /  " << va[i] << endl;
	}
	cout << endl<<endl;
	system("pause");
}