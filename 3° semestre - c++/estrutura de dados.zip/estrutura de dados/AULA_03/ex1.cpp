/*Fazer um programa que leia vários números inteiros e positivos. A leitura se encerra quando encontrar um número negativo ou quando o vetor ficar completo.
Sabe-se que o vetor possui, no máximo, 10 elementos. Gerar e imprimir um vetor onde cada elemento é o inverso do correspondente do vetor original.*/

#include <iostream>
using namespace std;


int main(){
	int i = 0,o;
	float val[10];
	do{
		system("clear||cls");
		cout << "entre com o " << i+1 << " valor:\n";
		cin >> val[i];
		i++;
	}while(i <= 9 && val[i-1] >= 0);
	
	system("clear||cls");
	
	for (o = 0;o <= i -1; o++){
		cout << "vetor " << o << ": " << -val[o] << endl; 
	}
	system("pause");
}