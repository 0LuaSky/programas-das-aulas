/*Criar um programa que crie um vetor com 10 posições e carregue com uma palavra, depois imprima o vetor de uma maneira que exiba a palavra ao contrário (ex. Casa...asac)*/

#include <iostream>
using namespace std;

int main(){
	int i=0,o;
	char v[10], w[10];
	cout << "entre com uma palavra de ate 10 letras (0 para parar de digitar)" << endl;
	do{
		cin >> v[i];
		i++;
	}while(i <= 9 && v[i-1] != '0');
	
	system("clear||cls");
	i--;
	
	if (v[i] == '0'){
		i--;
	}
	
	for(o = 0; o<=i; o++){
		cout << v[o];
		w[o] = v[i-o];
	}
	cout<<endl;
	for(o = 0; o<=i; o++){
		cout << w[o];
	}
	cout<<endl;
	cout<<endl;
	
	system("pause");
}