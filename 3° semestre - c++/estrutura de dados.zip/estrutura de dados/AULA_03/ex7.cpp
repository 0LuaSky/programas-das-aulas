/*Fazer um programa que, dados dois vetores de 7 posições cada, efetue as operações aritméticas básicas,
indicadas por um terceiro vetor cujos dados também são fornecidos pelo usuário, gerando e imprimindo um quarto vetor.*/

#include <iostream>
using namespace std;

int main(){
	int i, vet3[7];
	float vet1[7], vet2[7], vet4[7];
		
	for (i=0; i<7; i++){
		system("clear||cls");
		cout << i+1 << ") Entre com os 2 valores e o tipo de operacao (1:soma | 2:subtracao | 3:multiplicacao | 4:divisao)\n";
		cin >> vet1[i];
		cin >> vet2[i];
		cin >> vet3[i];
	}
	
	system("clear||cls");
	
	for (i=0; i<7; i++){
		switch (vet3[i]){
			case 1:{
				vet4[i] = vet1[i] + vet2[i];
				cout << vet1[i] << " + " << vet2[i] << " = " << vet4[i];
				break;
			}				
			case 2:{
				vet4[i] = vet1[i] - vet2[i];
				cout << vet1[i] << " - " << vet2[i] << " = " << vet4[i];
				break;
			}
			case 3:{
				vet4[i] = vet1[i] * vet2[i];
				cout << vet1[i] << " * " << vet2[i] << " = " << vet4[i];
				break;
			}
			case 4:{
				vet4[i] = vet1[i] / vet2[i];
				cout << vet1[i] << " / " << vet2[i] << " = " << vet4[i];
				break;
			} 
			default: cout << "operacao invalida "<<vet1[i]<<" | "<<vet2[i]; break;
		}
		cout << endl;
	}
	cout << endl << endl;
	system("pause");
}