/*Fazer um programa que digite vários números no vetor de tamanho máximo de 100 elementos, até digitar o número “0”. Imprimir quantos números iguais ao último número foram lidos.
O limite de números é 100.  Sem considerar o “0” como último número.*/

#include <iostream>
using namespace std;

int main(){
	int count, i=0, o, val[100];
	do{
		system("clear||cls");
		cout << "entre com o " << i+1 << " valor:\n";
		cin >> val[i];
		i++;
	}while(i < 10 && val[i-1] != 0);
	
	system("clear||cls");
	
	for (o = 0;o <= i-1; o++){
		if(val[i-1] == 0){
			if (val[o] == val[i-2]){
			count++;
			} 
		}else{
			if (val[o] == val[i-1]){
			count++;
			}
		}
		
	}
	cout << "existem " << count << " numeros iguais ao ultimo vetor";
	if(val[i-1] == 0){
		cout << " (" << val[i-2] << ")\n\n";
	}else{
		cout << " (" << val[i-1] << ")\n\n";
	}
	system("pause");
}