/*Faça um método que verifique quantas vezes um número é divisível por outro (dele até o 1).*/
#include <iostream>
using namespace std;

void asdfghjkl(int a, int b, int c){
	if(b > 0){
		if(a%b == 0){
			c++;
		}
		b--;
		asdfghjkl(a, b, c);
	}else{
		return; 
	}
}

int main(){
	int x, y, num=0;
	cout << "entre com com o numero que sera dividido:  ";
	cin >> x;
	cout << "entre o numero que ira dividir:  ";
	cin >> y;
	asdfghjkl(x,y,num);
	cout << x << " pode ser divido por " << num << " numero(s) demtro de.";
	cout << "\n\n";
	system("pause");
}