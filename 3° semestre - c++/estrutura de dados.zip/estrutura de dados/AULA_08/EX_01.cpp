/*Crie um metodo do tipo boelano para verificar se um numero é positivo e par, crie outro metodo que entre com o numero enquanto forem positivos e pares
(para isso chamar o metoro ja criado) e ao final retorne quantos numeros foram digitados*/

#include <iostream>
using namespace std;

bool par (int a){
	if(a>0 && a%2==0){
		return 1;
	}else{
		return 0;
	}
}

int qtd (int a){
	int x;
	cin >> x;
	if(par(x) == 1){
		a++;
		qtd(a);
	}else{
		return a;
	}
}

int main(){
	int num;
	cout << "Entre com os numeros:\n";
	num = qtd(0);
	cout << "Tiveram " << num << " numeros par e positivo.";
	cout << "\n\n";
	system("pause");
}