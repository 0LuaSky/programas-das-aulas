/*Dado o vetor : Vet [7] = {3,6,1,2,8,10,4}; faça o passo a passo da ordenação utilizando o Quicksort. */

#include <iostream>
using namespace std;

int partition(int vet[], int a, int b){
	
	int pivot = vet[a];
	int count = 0;
	for (int i = a + 1; i <= b; i++) {
		if (vet[i] <= pivot){
			count++;
		}
	}
	int pivotIndex = a + count;
	swap(vet[pivotIndex], vet[a]);
	int i = a, j = b;

	while (i < pivotIndex && j > pivotIndex) {

		while (vet[i] <= pivot) {
			i++;
		}

		while (vet[j] > pivot) {
			j--;
		}

		if (i < pivotIndex && j > pivotIndex) {
			swap(vet[i++], vet[j--]);
		}
	}

	return pivotIndex;
}

void quickSort(int vet[], int a, int b)
{
	if (a >= b){
		return;
	}
	int p = partition(vet, a, b);
	quickSort(vet, a, p - 1);
	quickSort(vet, p + 1, b);
}

int main(){
	int vet [7] = {3,6,1,2,8,10,4};
	quickSort(vet, 0, 6);
	for (int i = 0; i < 7; i++) {
		cout << vet[i] << " ";
	}
	cout << "\n\n";
	system("pause");
}