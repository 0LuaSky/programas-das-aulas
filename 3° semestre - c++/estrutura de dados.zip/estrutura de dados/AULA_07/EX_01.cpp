/*Criar um metodo de ordenação com 2 paremetros(um vetor de inteiro e uma variavel de inteira para o tamanho do vetor), esse metodo por ser "void" ele serve apenas para ordenar que esta no parametro.
criar um segundo metodo que faça a busca no vetor tambe, deve estar no paramentro metodo. depois criar um vetor e popular no "main",
chamar os metodos criados acima primeiro chamar o de ordenação e depoi o "busca binaria"*/

#include <iostream>
using namespace std;

void ordena(int vet[], int qtd){
	int vetorg[qtd], i, o, x;
	for(i=0; i<qtd; i++){
		
		vetorg[i] = vet[i];
		
		for(o=0; o<qtd; o++){
			if(vet[o] > vetorg[i]){
				vetorg[i] = vet[o];
				x = o;
			}
		}
		vet[x] = 0;
		
	}for(i=0; i<qtd; i++){
		vet[i] = vetorg[i];
	}
}

int localizador(int vet[], int qtd, int pos){
	int meio, inicio, fim;
	inicio = 0;
	fim = qtd-1;	
	while(inicio <= fim){
		meio = (fim + inicio)/2;	
		
		if(vet[meio] == pos){
			cout << "\no numero " << pos << " esta no indice " << meio;
			return 0;
		}else if(vet[meio] < pos){
			fim = meio - 1; 
		}
		else{
			inicio = meio + 1;
		}
	}
	cout << "\nerro, nao foi possivel achar o numero";
	return -1;
}

int main(){
	int qtd, i, o, pos;
	cout << "entre com a o tamanho do array: ";
	cin >> qtd;
	int vet[qtd];
	
	for(i=0; i<qtd; i++){
		system("clear||cls");
		cout << "arrey de " << qtd << " posicoes\n" << (qtd - i) << " espacos restantes\n\n";
		cout << "popule o vetor\n";
		for(o=0; o<i; o++){
			cout << vet[o] << "\t";
			if(((o+1)%10) == 0 && o != 0){
				cout << endl;
			}
		}
		cin >> vet[i];
	}
	
	system("clear||cls");
	
	cout << "Array nao organizado:\n";
	
	for(i=0; i<qtd; i++){
		cout << vet[i] << "\t";
			if(((i+1)%10) == 0 && i != 0){
				cout << endl;
			}
	}
	
	ordena(vet, qtd);
	
	cout << "\n\nArray organizado:\n";
	
	for(i=0; i<qtd; i++){
		cout << vet[i] << "\t";
			if(((i+1)%10) == 0 && i != 0){
				cout << endl;
			}
	}
	cout << "\n\nQual numero deseja exibir: ";
	cin >> pos;
	
	localizador(vet, qtd, pos);
	
	
	
	
	
	cout << endl << endl << endl;
	system("pause");
}