﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace miasdez
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i, num, sum;
            sum = 0;
            Console.WriteLine("selecione 10 numero:");
            for(i = 0; i < 10; i++)
            {
                num = Convert.ToInt32(Console.ReadLine());   
                if(num > 10)
                {
                    sum = sum + num;
                }
            }
            Console.Write("soma dos valores maior que dez: " + sum);
            Console.ReadKey();
        }
    }
}
