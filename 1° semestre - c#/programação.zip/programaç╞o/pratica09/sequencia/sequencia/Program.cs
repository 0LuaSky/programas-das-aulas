﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sequencia
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i, num;
            Console.Write("Digite o ultimo numero da sequencia:  ");
            num = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nSeguencia:\n");
            for(i=0; i <= num; i++)
            {
                if(i % 15 == 0)
                {
                    Console.Write("\n");
                }

                Console.Write(i + ".  ");
                if (i < 10)
                {
                    Console.Write(" ");
                }
            }
            Console.Write("\nFim da sequencia.");
            Console.ReadKey();
        }
    }
}
