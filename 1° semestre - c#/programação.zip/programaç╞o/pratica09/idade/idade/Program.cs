﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace idade
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, ac, i;
            i = 0;
            ac = 0;
            Console.WriteLine("Entre com a sua idade:"); 
            while (i < 10)
            {
                i++;
                num = Convert.ToInt32(Console.ReadLine());
                if(num > 18)
                {
                    ac++;
                }
            }
            Console.Write("\nNumero de pessoas com mais de 18 anos: " + ac);
            Console.ReadKey();
        }
    }
}
