﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace menor1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            do
            {
                Console.Clear();
                Console.Write("Digite um numero: ");
                num = Convert.ToInt32(Console.ReadLine());

            } while (num > 1);
            Console.ReadKey();
        }
    }
}
