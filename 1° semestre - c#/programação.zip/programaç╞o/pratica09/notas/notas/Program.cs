﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace notas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double notas, media, i, v;
            media = 0;
            i = 0;
        restart:
            Console.Clear();
            do
            {
                no:
                Console.Write((i + 1) + "a. nota: ");
                notas = Convert.ToDouble(Console.ReadLine());
                if(notas < 0 || notas > 10)
                {
                    goto no;
                }
                media = media + notas;
                i++;
            } 
            while (i != 4);
            Console.Write("Deseja continuar? 1=sim / 0=não: ");
            v = Convert.ToDouble(Console.ReadLine());
            if (v == 0)
            {
                Console.Write("Voutando para o inicio.");
                Console.ReadKey();
                goto restart;
            }

            media = media / i;
            Console.Write("\nMedia = " + media);
            Console.ReadKey();
        }
    }
}
