﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sequenciavirgula
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i, x;
            i = 1;
            while (i <= 10)
            {
                x = 0;
                while (x <= 10)
                {
                    if (i != 10)
                    {
                        Console.Write(" ");
                    }
                    Console.Write(i + "." + x + ";  ");
                    
                    x++;
                }
                i++;
                Console.Write("\n");
            }
            Console.ReadKey();
        }
    }
}
