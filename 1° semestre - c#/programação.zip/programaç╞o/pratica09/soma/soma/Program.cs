﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soma
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, soma;
            soma = 0;
            do
            {
                Console.Clear();
                Console.WriteLine("Entre com um numero para a soma: (digite 0 para finalizar)");
                num = Convert.ToInt32(Console.ReadLine());
                soma = soma + num;
            } while (num != 0);
            Console.Clear();
            Console.Write("soma total: {0}", soma);
            Console.ReadKey();
        }
    }
}
