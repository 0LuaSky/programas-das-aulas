﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buscador
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] nomes = new string[10];
            string nnome;
            int i, c;
            c = 0;
            for (i = 0; i < 10; i++)
            {
                Console.Clear();
                Console.WriteLine("Entre com o " + (i + 1) + "° nome: ");
                nomes[i] = Console.ReadLine();
            }
            Console.WriteLine("Entre com o nome que deseja procurar: ");
            nnome = Console.ReadLine();
            for (i = 0; i < 10; i++)
            {
                if(nnome == nomes[i])
                {
                    c = c + 1;
                }
            }
            if(c == 0)
            {
                Console.WriteLine("Não achei.");
            }
            else 
            {
                Console.WriteLine("Achei!!!");
            }
            Console.ReadKey();
        }
    }
}
