﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maior.menor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] num = new double[20];
            double maior, menor;
            int ma, me, i;
            ma = 0;
            me = 0;
            menor = 0;
            maior = 0;
            for (i = 0; i < 20; i++)
            {
                Console.Clear();
                Console.Write("Entre com o " + (i+1) + "° numero:  ");
                try
                {
                    num[i] = Convert.ToDouble(Console.ReadLine());
                }
                catch
                {
                    Console.Write("Entre com um numero real.");
                    Console.ReadKey();
                }
                if (i == 0)
                {
                    maior = num[i];
                    menor = num[i];
                    ma = i;
                    me = i;
                }
                else
                {
                    if (num[i] < menor)
                    {
                        menor = num[i];
                        me = i;
                    }
                    if (num[i] > maior)
                    {
                        maior = num[i];
                        ma = i;
                    }
                }
            }
            Console.WriteLine("O maior numero é " + maior + " e esta no vetor " + ma);
            Console.WriteLine("O menor numero é " + menor + " e esta no vetor " + me);
            Console.ReadKey();
        }
    }
}
