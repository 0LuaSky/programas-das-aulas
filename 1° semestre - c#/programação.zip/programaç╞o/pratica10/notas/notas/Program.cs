﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace notas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i;
            int[] notap1 = new int[5];
            int[] notap2 = new int[5];
            int[] notas = new int[5];
            string[] nomes = new string[5];

            for(i = 0; i < 5; i++)
            {
                restart:
                Console.Clear();
                Console.WriteLine("┌─────────────────────────────────────────────┐");
                Console.WriteLine("│Nome do {0}° aluno:                            │",i+1);
                Console.WriteLine("├───────────────────────┬─────────────────────┤");
                Console.WriteLine("│nota p1:               │nota p2:             │");
                Console.WriteLine("└───────────────────────┴─────────────────────┘");
                try
                {
                    Console.SetCursorPosition(19, 1);
                    nomes[i] = Console.ReadLine();
                    do {
                        Console.SetCursorPosition(10, 3);
                        Console.Write("   ");
                        Console.SetCursorPosition(10, 3);
                        notap1[i] = Convert.ToInt32(Console.ReadLine());
                    }while(notap1[i] <0 || notap1[i] >10);
                    do
                    {
                        Console.SetCursorPosition(34, 3);
                        Console.Write("   ");
                        Console.SetCursorPosition(34, 3);
                        notap2[i] = Convert.ToInt32(Console.ReadLine());
                    } while (notap2[i] < 0 || notap2[i] > 10);
                }
                catch
                {
                    Console.Clear();
                    Console.Write("Tente um valor valido.");
                    Console.ReadKey();
                    goto restart;
                }
            }
            for (i = 0; i < 5; i++)
            {
                notas[i] = (notap1[i] + notap2[i]) / 2;
                Console.Clear();
                Console.Write("\nNome: " + nomes[i]);
                Console.Write("P1: " + nomes[i]);
                Console.Write("P2: " + nomes[i]);
                Console.WriteLine("Media: " + notas[i]);
            }
            Console.ReadKey();
        }
    }
}
/*
─
│
┌
┐
└
┘
├
┤
┬
┴
┼
*/