﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ordem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] vet = new double[20];
            int i;
            for (i = 0; i < 20; i++)
            {
                Console.Clear();
                Console.Write("Entre com o "+ (i+1) + "° valor:  ");
                try
                {
                    vet[i] = Convert.ToDouble(Console.ReadLine());
                }
                catch
                {
                    Console.Write("Entre com um valor valido.");
                }
            }
            Console.Clear();
            Console.Write(" Original  | crescente | decrescente");
            for (i = 0; i < 20; i++)
            {
                Console.SetCursorPosition(1, (i + 1));
                Console.Write(vet[i]);
                Console.SetCursorPosition(11, (i + 1));
                Console.Write("|");
            }
            Array.Sort(vet);
            for (i = 0; i < 20; i++)
            {
                Console.SetCursorPosition(13, (i + 1));
                Console.Write(vet[i]);
                Console.SetCursorPosition(23, (i + 1));
                Console.Write("|");
            }
            Array.Reverse(vet);
            for (i = 0; i < 20; i++)
            {
                Console.SetCursorPosition(25, (i + 1));
                Console.Write(vet[i]);
            }
            Console.ReadKey();
        }
    }
}
