﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maior.menor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] q = new double[20];
            double maior;
            int ma, i;
            ma = 0;
            maior = 0;
            for (i = 0; i < 20; i++)
            {
                Erro:
                Console.Clear();
                Console.Write("Entre com o " + (i + 1) + "° numero:  ");
                try
                {
                    q[i] = Convert.ToDouble(Console.ReadLine());
                }
                catch
                {
                    Console.Write("Entre com um numero real.");
                    Console.ReadKey();
                }
                if (q[i] < 0)
                {
                    goto Erro;
                }
                if (i == 0)
                {
                    maior = q[i];
                    ma = i;
                }
                else
                {
                    if (q[i] > maior)
                    {
                        maior = q[i];
                        ma = i;
                    }
                }
            }
            Console.WriteLine("O maior numero é " + maior + " e esta no vetor " + ma);
            Console.ReadKey();
        }
    }
}