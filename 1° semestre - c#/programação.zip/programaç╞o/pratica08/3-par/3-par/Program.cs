﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_par
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, rest;
            do
            {
                Console.Clear();
                Console.WriteLine("╔═══════════════════════════════════╗");
                Console.WriteLine("║                          ╔══════╗ ║");
                Console.WriteLine("║ Entre com um numero par  ║      ║ ║");
                Console.WriteLine("║                          ╚══════╝ ║");
                Console.WriteLine("╚═══════════════════════════════════╝");

                Console.SetCursorPosition(29, 2);
                num = Convert.ToInt32(Console.ReadLine());
                rest = num % 2;
            } while (rest != 0);

            Console.Clear();
            Console.WriteLine("╔══════════════════╗");
            Console.WriteLine("║ Numero digitado  ║");
            Console.WriteLine("╠══════════════════╣");
            Console.WriteLine("║                  ║");
            Console.WriteLine("╚══════════════════╝");

            Console.SetCursorPosition(2, 3);
            Console.Write(num);

            Console.ReadKey();
        }
    }
}
/*
 ═
 ║
 ╔
 ╗
 ╚
 ╝
 ╠
 ╣
 ╦
 ╩
 ╬
 */