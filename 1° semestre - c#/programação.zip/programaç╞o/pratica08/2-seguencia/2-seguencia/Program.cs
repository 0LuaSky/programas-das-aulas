﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace _2_seguencia
{
    internal class Program
    {
        static void Main(string[] args)
        {//.║.╔.╗.╚.╝.╠.╣.╦.╬.╩.═
            int i, f, kkk, kkj;
            kkk = 0;
            Console.WriteLine("╔══════════════════════════════╦═══════╗");
            Console.WriteLine("║ Entre com o primeiro termo   ║       ║");
            Console.WriteLine("╠══════════════════════════════╬═══════╣");
            Console.WriteLine("║ Entre a quantidade de termos ║       ║");
            Console.WriteLine("╚══════════════════════════════╩═══════╝");
            Console.SetCursorPosition(33, 1);
            i = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(33, 3);
            f = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            while(i <= f)
            {
                kkk++;
                kkj = kkk % 20;
                if (kkj == 0)
                {
                    Console.WriteLine("\n");
                }
                i++;
                Console.Write(i + " ");
                Thread.Sleep(500);
            }
            Console.WriteLine("\nFim da seguencia.");
            Console.ReadKey();
        }
    }
}
