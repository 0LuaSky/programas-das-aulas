﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace _1_tabuada
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, tab, i;
            Console.WriteLine("╔════════════════════╦═════════╗");
            Console.WriteLine("║ Entre com o numero ║         ║");
            Console.WriteLine("╚════════════════════╩═════════╝");
            Console.SetCursorPosition(24, 1);
            num = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("╔════════════════════╗");
            for (i = 1; i <= 10; i++)
            {
                tab = num * i;
                Console.SetCursorPosition(0, i);
                Console.WriteLine("║                    ║");
                Console.SetCursorPosition(2, i);
                Console.Write(tab);
                Thread.Sleep(500);

            }
            Console.SetCursorPosition(0, i);
            Console.WriteLine("╚════════════════════╝");
            Console.ReadKey();
        }
    }
}
