﻿//2 – Elaborar um programa que permita que o usuário digite uma temperatura em graus Celsius e o programa converta para Kelvin.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kelvin
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Kevin... tem algo de errado com esse nome";
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            double selso, kevin;
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(4, 1);
            Console.WriteLine("*-------------------------*-----------------------*");
            Console.SetCursorPosition(4, 2);
            Console.WriteLine("|                         |                       |");
            Console.SetCursorPosition(4, 3);
            Console.WriteLine("|                         |                       |");
            Console.SetCursorPosition(4, 4);
            Console.WriteLine("|                         |                       |");
            Console.SetCursorPosition(4, 5);
            Console.WriteLine("*-------------------------*-----------------------*");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.SetCursorPosition(6, 2);
            Console.WriteLine("temperatudo em Celsius:");
            Console.SetCursorPosition(32, 2);
            Console.WriteLine("temperatudo em Kelvin");
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.SetCursorPosition(6, 4);
            selso = Convert.ToDouble(Console.ReadLine());
            Console.SetCursorPosition(6, 4);
            Console.WriteLine(selso + " °F");
            kevin = selso + 273.15;
            Console.SetCursorPosition(32, 4);
            Console.WriteLine(kevin + " °K");
            Console.ReadKey();
        }
    }
}
