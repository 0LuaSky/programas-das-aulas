﻿//4 – Criar um programa que permita que o usuário digite seu peso em kg, calcular e mostrar: Peso em gramas. O peso com um acréscimo de 10%

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace peso
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Programa balança... aquelas de farmacia que sempre mostra errado no caso";
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            double kilos, gramas;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.SetCursorPosition(4, 1);
            Console.WriteLine("+-----------------------------+");
            Console.SetCursorPosition(4, 2);
            Console.WriteLine("|                             |");
            Console.SetCursorPosition(4, 3);
            Console.WriteLine("|                             |");
            Console.SetCursorPosition(4, 4);
            Console.WriteLine("|                             |");
            Console.SetCursorPosition(4, 5);
            Console.WriteLine("+-----------------------------+");
            Console.SetCursorPosition(4, 7);
            Console.WriteLine("+-----------------------------+");
            Console.SetCursorPosition(4, 8);
            Console.WriteLine("|                             |");
            Console.SetCursorPosition(4, 9);
            Console.WriteLine("|                             |");
            Console.SetCursorPosition(4, 10);
            Console.WriteLine("|                             |");
            Console.SetCursorPosition(4, 11);
            Console.WriteLine("+-----------------------------+");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.SetCursorPosition(6, 2);
            Console.WriteLine("Coloque seu peso em quilos: ");
            Console.SetCursorPosition(6, 8);
            Console.WriteLine("Seu peso em gramas:");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.SetCursorPosition(6, 4);
            kilos = Convert.ToDouble(Console.ReadLine());
            Console.SetCursorPosition(6, 4);
            Console.WriteLine(kilos + " kg");
            gramas = (kilos + ((kilos / 100) * 10) ) *1000;
            Console.SetCursorPosition(6, 10);
            Console.WriteLine(gramas + " g");
            Console.ReadKey();
        }
    }
}
