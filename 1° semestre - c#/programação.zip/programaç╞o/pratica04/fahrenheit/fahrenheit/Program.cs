﻿//3 - Escreva um algoritmo para ler uma temperatura em graus Fahrenheit, calcular e escrever o valor correspondente em graus Celsius 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fahrenheit
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Farem... fahrnhei... a sei la essa porcaria que os gringo usa";
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            double farem, kelvin;
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(4, 1);
            Console.WriteLine("*----------------------------*------------------------*");
            Console.SetCursorPosition(4, 2);
            Console.WriteLine("|                            |                        |");
            Console.SetCursorPosition(4, 3);
            Console.WriteLine("|                            |                        |");
            Console.SetCursorPosition(4, 4);
            Console.WriteLine("|                            |                        |");
            Console.SetCursorPosition(4, 5);
            Console.WriteLine("*----------------------------*------------------------*");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.SetCursorPosition(6, 2);
            Console.WriteLine("temperatudo em fahrenheit:");
            Console.SetCursorPosition(35, 2);
            Console.WriteLine("temperatudo em kelvin:");
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.SetCursorPosition(6, 4);
            farem = Convert.ToDouble(Console.ReadLine());
            Console.SetCursorPosition(6, 4);
            Console.WriteLine(farem + " °F");
            kelvin = (farem - 32) * (5 / 9);
            Console.SetCursorPosition(35, 4);
            Console.WriteLine(kelvin + " °K");
            Console.ReadKey();
        }
    }
}
