﻿//1 – Criar um programa que permita a digitação do salário mínimo e do salário do usuário, calcular quantos salários mínimos a pessoa ganha

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace salario
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Salario";
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            double salario, recebe, quantidade;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(4, 1);
            Console.WriteLine("*--------------------------------------------*-----------------------------------------------*");
            Console.SetCursorPosition(4, 2);
            Console.WriteLine("|                                            |                                               |");
            Console.SetCursorPosition(4, 3);
            Console.WriteLine("|                                            |                                               |");
            Console.SetCursorPosition(4, 4);
            Console.WriteLine("|                                            |                                               |");
            Console.SetCursorPosition(4, 5);
            Console.WriteLine("*--------------------------------------------*-----------------------------------------------*");
            Console.SetCursorPosition(4, 7);
            Console.WriteLine("*--------------------------------------------------------------------------------------------*");
            Console.SetCursorPosition(4, 8);
            Console.WriteLine("|                                                                                            |");
            Console.SetCursorPosition(4, 9);
            Console.WriteLine("|                                                                                            |");
            Console.SetCursorPosition(4, 10);
            Console.WriteLine("|                                                                                            |");
            Console.SetCursorPosition(4, 11);
            Console.WriteLine("*--------------------------------------------------------------------------------------------*");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.SetCursorPosition(6, 2);
            Console.WriteLine("Entre com o valor do salario minimo atual");
            Console.SetCursorPosition(52, 2);
            Console.WriteLine("Entre com o valor do salario que voce recebe");
            Console.SetCursorPosition(6, 8);
            Console.WriteLine("Essa é a quantidade de salarios minimos que voce recebe");
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.SetCursorPosition(6, 4);
            salario = Convert.ToDouble(Console.ReadLine());
            Console.SetCursorPosition(6, 4);
            Console.WriteLine(salario + " RS");
            Console.SetCursorPosition(52, 4);
            recebe = Convert.ToDouble(Console.ReadLine());
            Console.SetCursorPosition(52, 4);
            Console.WriteLine(recebe + " RS");
            quantidade = recebe / salario;
            Console.SetCursorPosition(6, 10);
            Console.WriteLine(quantidade + " RS");
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.ReadKey();
        }
    }
}
