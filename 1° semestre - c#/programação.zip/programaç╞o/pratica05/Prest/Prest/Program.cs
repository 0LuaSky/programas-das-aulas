﻿//A prefeitura esta concedendo empréstimos a seus funcionários seguindo a regra de que a prestação não pode ser maior que 30% do valor do salário.
//Criar um programa que permita a entrada do salário e da prestação do empréstimo, verificar se a prestação digitada corresponde a regra de empréstimo descrita acima.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            nop:
            Console.Title = "Emprestimos";
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.SetCursorPosition(2, 1);
            Console.WriteLine("┌───────────────────────────────────┐");
            Console.SetCursorPosition(2, 2);
            Console.WriteLine("│                                   │");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine("│                                   │");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("├───────────────────────────────────┤");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine("│                                   │");
            Console.SetCursorPosition(2, 6);
            Console.WriteLine("│                                   │");
            Console.SetCursorPosition(2, 7);
            Console.WriteLine("└───────────────────────────────────┘");

            Double sal, emp, por;
            Console.SetCursorPosition(4, 2);
            Console.WriteLine("entre com o valor do seu salário:");
            Console.SetCursorPosition(4, 5);
            Console.WriteLine("entre com o valor do emprestimo:");
            Console.SetCursorPosition(4, 3);
            sal = Convert.ToDouble(Console.ReadLine());
            Console.SetCursorPosition(4, 6);
            emp = Convert.ToDouble(Console.ReadLine());
            por = (sal * 30) / 100;
            if (emp < por)
            {
                Console.Clear();
                Console.SetCursorPosition(2, 1);
                Console.WriteLine("┌───────────────────────────────────┐");
                Console.SetCursorPosition(2, 2);
                Console.WriteLine("│                                   │");
                Console.SetCursorPosition(2, 3);
                Console.WriteLine("│                                   │");
                Console.SetCursorPosition(2, 4);
                Console.WriteLine("└───────────────────────────────────┘");
                Console.SetCursorPosition(4, 2);
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("O valor foi aceito.");
            }
            else
            {
                Console.Clear();
                Console.SetCursorPosition(2, 1);
                Console.WriteLine("┌───────────────────────────────────┐");
                Console.SetCursorPosition(2, 2);
                Console.WriteLine("│                                   │");
                Console.SetCursorPosition(2, 3);
                Console.WriteLine("│                                   │");
                Console.SetCursorPosition(2, 4);
                Console.WriteLine("└───────────────────────────────────┘");
                Console.SetCursorPosition(4, 2);
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("o Valor não foi aceito.");
                Console.ReadKey();
                goto nop;
            }
            Console.ReadKey();
        }
    }
}
