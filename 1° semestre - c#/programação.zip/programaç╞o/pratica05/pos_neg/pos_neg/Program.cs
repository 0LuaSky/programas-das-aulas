﻿//Criar um programa que permita que o usuário digite um número, verificar e mostrar na tela se o número é positivo, negativo ou zero.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pos_neg
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Programa positivo ou negativo";
            Console.BackgroundColor = ConsoleColor.DarkYellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.SetCursorPosition(2, 2);
            Console.WriteLine("╔═════════════════════════════╗");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine("║                             ║");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("║                             ║");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine("╚═════════════════════════════╝");
            Console.SetCursorPosition(2, 6);
            Console.WriteLine("╔═════════════════════════════╗");
            Console.SetCursorPosition(2, 7);
            Console.WriteLine("║                             ║");
            Console.SetCursorPosition(2, 8);
            Console.WriteLine("║                             ║");
            Console.SetCursorPosition(2, 9);
            Console.WriteLine("╚═════════════════════════════╝"); 
            
            
            Double num1;
            Console.SetCursorPosition(4,3);
            Console.WriteLine("Entre com um valor:");
            Console.SetCursorPosition(4, 7);
            Console.WriteLine("O valor que você colocou é:");
            Console.SetCursorPosition(4, 4);
            num1 = Convert.ToDouble(Console.ReadLine());
            if (num1 == 0)
            {
                Console.SetCursorPosition(4, 8);
                Console.WriteLine("NULO.");
            }
            if (num1 < 0)
            {
                Console.SetCursorPosition(4, 8);
                Console.WriteLine("NEGATIVO.");
            }
            if (num1 > 0)
            {
                Console.SetCursorPosition(4, 8);
                Console.WriteLine("POSITIVO");
            }
            Console.ReadKey();
        }
    }
}
