﻿//Crie um programa que permita que o usuário digite o valor das vendas que executou neste mês, imprimir na tela o premio que ganhou por estas vendas de acordo com os critérios abaixo:
//Menor que R$ 1000,00 (Sem premio).
//Maior igual a R$ 1000,00 e menor que R$ 3000,00 (premio de R$ 150,00).
//Maior igual a R$ 3000,00 (premio de R$ 300,00).

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace premio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Programa de premios aniversario guanabara";
            Console.BackgroundColor = ConsoleColor.DarkYellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.SetCursorPosition(2, 2);
            Console.WriteLine("╔═════════════════════════════════════════════╗");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine("║                                             ║");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("║                                             ║");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine("╚═════════════════════════════════════════════╝");

            Double val;
            Console.SetCursorPosition(4, 3);
            Console.WriteLine("Entre com o valor que voce vendeu esse mês:");
            Console.SetCursorPosition(4, 4);
            val = Convert.ToDouble(Console.ReadLine());

            Console.Clear();
            Console.SetCursorPosition(2, 2);
            Console.WriteLine("╔═════════════════════════════════════════════╗");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine("║                                             ║");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("║                                             ║");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine("╚═════════════════════════════════════════════╝");
            if (val >= 3000)
            {
                Console.SetCursorPosition(4, 3);
                Console.WriteLine("Você recebeu um premio de 300,00R$");
                Console.SetCursorPosition(4, 4);
                Console.WriteLine("parabems!!!");
            }
            else if (val >= 1000)
            {
                Console.SetCursorPosition(4, 3);
                Console.WriteLine("Você Recebeu um premio de 100,R$.");
            }
            else
            {
                Console.SetCursorPosition(4, 3);
                Console.WriteLine("Você não vendeu o suficiente");
                Console.SetCursorPosition(4, 4);
                Console.WriteLine("melhore seus numeros no proximo mês");
            }
            Console.ReadKey();
        }
    }
}
