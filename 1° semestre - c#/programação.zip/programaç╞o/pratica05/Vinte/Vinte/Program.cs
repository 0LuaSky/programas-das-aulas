﻿//Criar um programa que permita que o usuário digite um número, verificar se este número é maior que 20,
//se for maior mostrar na tela a metade do número digitado, caso seja menor 20 mostrar o dobro do número digitado.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Programa dos vintão";
            Console.BackgroundColor = ConsoleColor.DarkYellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.SetCursorPosition(2, 2);
            Console.WriteLine("╔═══════════════════════╗");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine("║                       ║");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("║                       ║");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine("║                       ║");
            Console.SetCursorPosition(2, 6);
            Console.WriteLine("╚═══════════════════════╝");
            Console.SetCursorPosition(2, 7);
            Console.WriteLine("╔═══════════════════════╗");
            Console.SetCursorPosition(2, 8);
            Console.WriteLine("║                       ║");
            Console.SetCursorPosition(2, 9);
            Console.WriteLine("║                       ║");
            Console.SetCursorPosition(2, 10);
            Console.WriteLine("║                       ║");
            Console.SetCursorPosition(2, 11);
            Console.WriteLine("╚═══════════════════════╝");

            double num1, num;
            Console.SetCursorPosition(4, 3);
            Console.WriteLine("Entre com o numero:");
        restart:
            Console.SetCursorPosition(4, 5);
            num1 = Convert.ToDouble(Console.ReadLine());
            if (num1 > 20)
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.SetCursorPosition(4, 5);
                Console.WriteLine(num1);
                num = num1 / 2;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.SetCursorPosition(4, 8);
                Console.WriteLine("O numero agora é:");
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.SetCursorPosition(4, 10);
                Console.WriteLine(num);
                Console.ForegroundColor = ConsoleColor.Black;
            }
            else if (num1 < 20)
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.SetCursorPosition(4, 5);
                Console.WriteLine(num1);
                num = num1 * 2;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.SetCursorPosition(4, 8);
                Console.WriteLine("O numero agora é:");
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.SetCursorPosition(4, 10);
                Console.WriteLine(num);
                Console.ForegroundColor = ConsoleColor.Black;
            }
            else if (num1 == 20)
            {
                Console.SetCursorPosition(4, 3);
                Console.WriteLine("coloque outro numero:");
                Console.SetCursorPosition(2, 5);
                Console.WriteLine("║                       ║");
                goto restart;
            }
            Console.ReadKey();
        }
    }
}
