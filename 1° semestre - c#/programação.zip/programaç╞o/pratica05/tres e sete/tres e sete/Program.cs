﻿//Crie um programa que permite que o usuário digite o valor de um numero qualquer,
//verificar se o numero é múltiplo de 3 e de 7 ao mesmo tempo, caso seja imprimir na tela “Múltiplo de 3 e 7”, caso não imprimir “Não é múltiplo”.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tres_e_sete
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Programa 3 e 7 bixo";
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.SetCursorPosition(2, 2);
            Console.WriteLine("╔══════════════════════╗");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine("║                      ║");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("║                      ║");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine("╚══════════════════════╝");

            Double num1, rest3, rest7;
            Console.SetCursorPosition(4, 3);
            Console.WriteLine("Entre com um valor:");
            Console.SetCursorPosition(4, 4);
            num1 = Convert.ToDouble(Console.ReadLine());
            rest3 = num1 % 3;
            rest7 = num1 % 7;
            if (rest3 == 0 && rest7 == 0)
            {
                Console.Clear();
                Console.SetCursorPosition(2, 2);
                Console.WriteLine("╔═════════════════════════════════╗");
                Console.SetCursorPosition(2, 3);
                Console.WriteLine("║                                 ║");
                Console.SetCursorPosition(2, 4);
                Console.WriteLine("╚═════════════════════════════════╝");
                Console.SetCursorPosition(4, 3);
                Console.WriteLine("O valor é multiplo de 7 e de 3.");
            }
            else
            {
                Console.Clear();
                Console.SetCursorPosition(2, 2);
                Console.WriteLine("╔════════════════════════════════════════════════════╗");
                Console.SetCursorPosition(2, 3);
                Console.WriteLine("║                                                    ║");
                Console.SetCursorPosition(2, 4);
                Console.WriteLine("╚════════════════════════════════════════════════════╝");
                Console.SetCursorPosition(4, 3);
                Console.WriteLine("O valor não é multiplo de 7 e de 3 ao mesmo tempo.");
            }
            Console.ReadKey();
        }
    }
}
