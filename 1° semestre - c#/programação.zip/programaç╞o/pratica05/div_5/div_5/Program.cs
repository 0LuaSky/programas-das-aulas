﻿//Criar um programa que permita que o usuário digite um número, verificar se o mesmo é múltiplo de 5

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace div_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Programa dos cincão";
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.SetCursorPosition(2, 2);
            Console.WriteLine("╔═══════════════════════╗");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine("║                       ║");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("║                       ║");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine("║                       ║");
            Console.SetCursorPosition(2, 6);
            Console.WriteLine("╚═══════════════════════╝");
            Console.SetCursorPosition(2, 7);
            Console.WriteLine("╔═══════════════════════╗");
            Console.SetCursorPosition(2, 8);
            Console.WriteLine("║                       ║");
            Console.SetCursorPosition(2, 9);
            Console.WriteLine("╚═══════════════════════╝");
            Console.SetCursorPosition(2, 10);
            Console.WriteLine("╔═════╗           ╔═════╗");
            Console.SetCursorPosition(2, 11);
            Console.WriteLine("║ Sim ║           ║ Não ║");
            Console.SetCursorPosition(2, 12);
            Console.WriteLine("╚═════╝           ╚═════╝");

            int num1, rest;
            Console.SetCursorPosition(4, 3);
            Console.WriteLine("insira um numero:");
            Console.SetCursorPosition(4, 8);
            Console.WriteLine("X é multiplo de 5?");
            Console.SetCursorPosition(4, 5);
            num1 = Convert.ToInt16(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.SetCursorPosition(4, 5);
            Console.WriteLine(num1);
            rest = num1 % 5;
            if(rest == 0)
            {
                Console.ForegroundColor = ConsoleColor.Black;
                Console.SetCursorPosition(4, 8);
                Console.WriteLine(num1 + " é multiplo de 5?");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.SetCursorPosition(2, 10);
                Console.WriteLine("╔═════╗");
                Console.SetCursorPosition(2, 11);
                Console.WriteLine("║ Sim ║");
                Console.SetCursorPosition(2, 12);
                Console.WriteLine("╚═════╝");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Black;
                Console.SetCursorPosition(4, 8);
                Console.WriteLine(num1 + " é multiplo de 5?");
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.SetCursorPosition(20, 10);
                Console.WriteLine("╔═════╗");
                Console.SetCursorPosition(20, 11);
                Console.WriteLine("║ Não ║");
                Console.SetCursorPosition(20, 12);
                Console.WriteLine("╚═════╝");
            }
            Console.ReadKey();
        }
    }
}
