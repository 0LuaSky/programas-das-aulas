﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace opcoes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "calculadora. uWu";
            restart:
            Console.Clear();
            Console.SetCursorPosition(2, 1);
            Console.WriteLine("╔════════════════════════╗");
            Console.SetCursorPosition(2, 2);
            Console.WriteLine("║ selecione a operação:  ║");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine("║                        ║");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("╠════════════════════════╣");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine("║ ( 1 ) adição.          ║");
            Console.SetCursorPosition(2, 6);
            Console.WriteLine("║ ( 2 ) subtração.       ║");
            Console.SetCursorPosition(2, 7);
            Console.WriteLine("║ ( 3 ) multiplicação.   ║");
            Console.SetCursorPosition(2, 8);
            Console.WriteLine("║ ( 4 ) Divisão.         ║");
            Console.SetCursorPosition(2, 9);
            Console.WriteLine("╚════════════════════════╝");

            int op;
            double num, num1, num2;
            Console.SetCursorPosition(4, 3);
            op = Convert.ToInt32(Console.ReadLine());
            switch (op)
            {
                default:
                    {
                        goto restart;
                    }
                case 1:
                    {
                        Console.Clear();
                        Console.SetCursorPosition(2, 1);
                        Console.WriteLine("╔══════════════════════════════════╗");
                        Console.SetCursorPosition(2, 2);
                        Console.WriteLine("║              ADIÇÃO              ║");
                        Console.SetCursorPosition(2, 3);
                        Console.WriteLine("╠═════════════════╦════════════════╣");
                        Console.SetCursorPosition(2, 4);
                        Console.WriteLine("║ primeiro valor: ║ Segundo valor: ║");
                        Console.SetCursorPosition(2, 5);
                        Console.WriteLine("║                 ║                ║");
                        Console.SetCursorPosition(2, 6);
                        Console.WriteLine("╠═════════════════╩════════════════╣");
                        Console.SetCursorPosition(2, 7);
                        Console.WriteLine("║ Resposta:                        ║");
                        Console.SetCursorPosition(2, 8);
                        Console.WriteLine("╚══════════════════════════════════╝");
                        Console.SetCursorPosition(4, 5);
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.SetCursorPosition(22, 5);
                        num2 = Convert.ToInt32(Console.ReadLine());
                        num = num1 + num2;
                        Console.SetCursorPosition(14, 7);
                        Console.WriteLine(num);
                        break;
                    }
                case 2:
                    {
                        Console.Clear();
                        Console.SetCursorPosition(2, 1);
                        Console.WriteLine("╔══════════════════════════════════╗");
                        Console.SetCursorPosition(2, 2);
                        Console.WriteLine("║             SUBTRAÇÃO            ║");
                        Console.SetCursorPosition(2, 3);
                        Console.WriteLine("╠═════════════════╦════════════════╣");
                        Console.SetCursorPosition(2, 4);
                        Console.WriteLine("║ primeiro valor: ║ Segundo valor: ║");
                        Console.SetCursorPosition(2, 5);
                        Console.WriteLine("║                 ║                ║");
                        Console.SetCursorPosition(2, 6);
                        Console.WriteLine("╠═════════════════╩════════════════╣");
                        Console.SetCursorPosition(2, 7);
                        Console.WriteLine("║ Resposta:                        ║");
                        Console.SetCursorPosition(2, 8);
                        Console.WriteLine("╚══════════════════════════════════╝");
                        Console.SetCursorPosition(4, 5);
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.SetCursorPosition(22, 5);
                        num2 = Convert.ToInt32(Console.ReadLine());
                        num = num1 - num2;
                        Console.SetCursorPosition(14, 7);
                        Console.WriteLine(num);
                        break;
                    }
                case 3:
                    {
                        Console.Clear();
                        Console.SetCursorPosition(2, 1);
                        Console.WriteLine("╔══════════════════════════════════╗");
                        Console.SetCursorPosition(2, 2);
                        Console.WriteLine("║            MULTIPLICÃO           ║");
                        Console.SetCursorPosition(2, 3);
                        Console.WriteLine("╠═════════════════╦════════════════╣");
                        Console.SetCursorPosition(2, 4);
                        Console.WriteLine("║ primeiro valor: ║ Segundo valor: ║");
                        Console.SetCursorPosition(2, 5);
                        Console.WriteLine("║                 ║                ║");
                        Console.SetCursorPosition(2, 6);
                        Console.WriteLine("╠═════════════════╩════════════════╣");
                        Console.SetCursorPosition(2, 7);
                        Console.WriteLine("║ Resposta:                        ║");
                        Console.SetCursorPosition(2, 8);
                        Console.WriteLine("╚══════════════════════════════════╝");
                        Console.SetCursorPosition(4, 5);
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.SetCursorPosition(22, 5);
                        num2 = Convert.ToInt32(Console.ReadLine());
                        num = num1 * num2;
                        Console.SetCursorPosition(14, 7);
                        Console.WriteLine(num);
                        break;
                    }
                case 4:
                    {
                        Console.Clear();
                        Console.SetCursorPosition(2, 1);
                        Console.WriteLine("╔══════════════════════════════════╗");
                        Console.SetCursorPosition(2, 2);
                        Console.WriteLine("║              DIVISÃO             ║");
                        Console.SetCursorPosition(2, 3);
                        Console.WriteLine("╠═════════════════╦════════════════╣");
                        Console.SetCursorPosition(2, 4);
                        Console.WriteLine("║ primeiro valor: ║ Segundo valor: ║");
                        Console.SetCursorPosition(2, 5);
                        Console.WriteLine("║                 ║                ║");
                        Console.SetCursorPosition(2, 6);
                        Console.WriteLine("╠═════════════════╩════════════════╣");
                        Console.SetCursorPosition(2, 7);
                        Console.WriteLine("║ Resposta:                        ║");
                        Console.SetCursorPosition(2, 8);
                        Console.WriteLine("╚══════════════════════════════════╝");
                        Console.SetCursorPosition(4, 5);
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.SetCursorPosition(22, 5);
                        num2 = Convert.ToInt32(Console.ReadLine());
                        num = num1 / num2;
                        Console.SetCursorPosition(14, 7);
                        Console.WriteLine(num);
                        break;
                    }
            }
            Console.ReadKey();
            goto restart;
        }
    }
}