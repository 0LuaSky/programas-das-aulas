﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace opcoes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "calculadora. uWu";
            restart:
            Console.Clear();
            Console.SetCursorPosition(2, 1);
            Console.WriteLine("╔════════════════════════╗");
            Console.SetCursorPosition(2, 2);
            Console.WriteLine("║ Selecione a operação.  ║");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine("╠════════════════════════╣");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("║ ( 1 ) Bhaskara.        ║");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine("║ ( 2 ) Força.           ║");
            Console.SetCursorPosition(2, 6);
            Console.WriteLine("║ ( 3 ) Velocidade.      ║");
            Console.SetCursorPosition(2, 7);
            Console.WriteLine("╠════════════════════════╣");
            Console.SetCursorPosition(2, 8);
            Console.WriteLine("║                        ║");
            Console.SetCursorPosition(2, 9);
            Console.WriteLine("╚════════════════════════╝");
            
            int op;
            double num, num0, num1, num2, num3;
            Console.SetCursorPosition(4, 8);
            op = Convert.ToInt32(Console.ReadLine());
            switch (op)
            {
                default: {
                        Console.Clear();
                        Console.SetCursorPosition(2, 2);
                        Console.WriteLine("╔═════════════════════════════════════════════════╗");
                        Console.SetCursorPosition(2, 3);
                        Console.WriteLine("║ Escolha uma das opções disponiveis. (1, 2 ou 3) ║ ");
                        Console.SetCursorPosition(2, 4);
                        Console.WriteLine("╚═════════════════════════════════════════════════╝");
                        Console.ReadKey();
                        goto restart;
                    }
                case 1: {
                        Console.Clear();
                        Console.SetCursorPosition(2, 1);
                        Console.WriteLine("╔═════════════╦═════════════╦═════════════╗");
                        Console.SetCursorPosition(2, 2);
                        Console.WriteLine("║ valor de a: ║ Valor de B: ║ Valor de C: ║");
                        Console.SetCursorPosition(2, 3);
                        Console.WriteLine("║             ║             ║             ║");
                        Console.SetCursorPosition(2, 4);
                        Console.WriteLine("╠═════════════╩═════════════╩═════════════╣");
                        Console.SetCursorPosition(2, 5);
                        Console.WriteLine("║ Resposta:                               ║");
                        Console.SetCursorPosition(2, 6);
                        Console.WriteLine("╚═════════════════════════════════════════╝");
                        Console.SetCursorPosition(4, 3);
                        num1 = Convert.ToDouble(Console.ReadLine());
                        Console.SetCursorPosition(18, 3);
                        num2 = Convert.ToDouble(Console.ReadLine());
                        Console.SetCursorPosition(32, 3);
                        num3 = Convert.ToDouble(Console.ReadLine());
                        num = (-num2 + Math.Sqrt((num2 * num2) - (4 * num1 * num3))) / (2 * num1);
                        num0 = (-num2 - Math.Sqrt((num2 * num2) - (4 * num1 * num3))) / (2 * num1);
                        Console.SetCursorPosition(14, 5);
                        Console.WriteLine(num + "  // " + num0);
                        break;
                    }
                case 2:{
                        Console.Clear();
                        Console.SetCursorPosition(2, 1);
                        Console.WriteLine("╔══════════════════╦══════════════════════╗");
                        Console.SetCursorPosition(2, 2);
                        Console.WriteLine("║ valor da massa:  ║ Valor da aceleração: ║");
                        Console.SetCursorPosition(2, 3);
                        Console.WriteLine("║                  ║                      ║");
                        Console.SetCursorPosition(2, 4);
                        Console.WriteLine("╠══════════════════╩══════════════════════╣");
                        Console.SetCursorPosition(2, 5);
                        Console.WriteLine("║ Resposta:                               ║");
                        Console.SetCursorPosition(2, 6);
                        Console.WriteLine("╚═════════════════════════════════════════╝");
                        Console.SetCursorPosition(4, 3);
                        num1 = Convert.ToDouble(Console.ReadLine());
                        Console.SetCursorPosition(23, 3);
                        num2 = Convert.ToDouble(Console.ReadLine());
                        Console.SetCursorPosition(14, 5);
                        num = num1 * num2;
                        Console.WriteLine(num);
                        break;
                    }
                case 3:
                    {
                        Console.Clear();
                        Console.SetCursorPosition(2, 1);
                        Console.WriteLine("╔═════════════════════╦═════════════╦════════╗");
                        Console.SetCursorPosition(2, 2);
                        Console.WriteLine("║ Velocidade inicial: ║ Aceleração: ║ Tempo: ║");
                        Console.SetCursorPosition(2, 3);
                        Console.WriteLine("║                     ║             ║        ║");
                        Console.SetCursorPosition(2, 4);
                        Console.WriteLine("╠═════════════════════╩═════════════╩════════╣");
                        Console.SetCursorPosition(2, 5);
                        Console.WriteLine("║ Resposta:                                  ║");
                        Console.SetCursorPosition(2, 6);
                        Console.WriteLine("╚════════════════════════════════════════════╝");
                        Console.SetCursorPosition(4, 3);
                        num1 = Convert.ToDouble(Console.ReadLine());
                        Console.SetCursorPosition(26, 3);
                        num2 = Convert.ToDouble(Console.ReadLine());
                        Console.SetCursorPosition(40, 3);
                        num3 = Convert.ToDouble(Console.ReadLine());
                        num = num1 + (num2 * num3);
                        Console.SetCursorPosition(14, 5);
                        Console.WriteLine(num);
                        break;
                    }

            }
            Console.ReadKey();
            goto restart;
        }
    }
}
